package ar.edu.unlp.taller.de.lenguajes.II;

public enum Lenguas {
	ESPANIOL, INGLÉS, PORTUGUÉS, FRANCÉS, ITALIANO, COREANO, JAPONÉS, CHINO, RUSO, ÁRABE, ALEMAN, TURCO, TAILANDÉS;
}
